<?php
// Heading
$_['heading_title'] = 'Extension extractor';
$_['menu_title'] = 'Extension extractor';

// Text
$_['process_complete'] = 'Process completed';
$_['extract_list_extension'] = 'Extract the list of extensions';
$_['dir_save_locaiton'] = 'Save Folder: ';
$_['text_position'] = ' Wait to extract the cycle ocmod module: ';
$_['text_total'] = ' out of: ';
$_['text_list'] = 'Process log';
$_['button_action'] = 'Extract extension';
$_['status_upload'] = 'Status';
$_['title_1'] = 'Extract all the extensions present in opencart';