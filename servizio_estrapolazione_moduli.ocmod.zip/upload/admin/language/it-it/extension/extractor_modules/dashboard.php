<?php
// Heading
$_['heading_title'] = 'Estrattore estensioni';
$_['menu_title'] = 'Estrattore estensioni';

// Text
$_['process_complete'] = 'Processo completato';
$_['extract_list_extension'] = 'Estratta la lista delle estensioni';
$_['dir_save_locaiton'] = 'Cartella di salvataggio: ';
$_['text_position'] = ' Attendere estrazione modulo ocmod ciclo: ';
$_['text_total'] = ' su: ';
$_['text_list'] = 'Log processo';
$_['button_action'] = 'Estrai i estensioni';
$_['status_upload'] = 'Stato del caricamento';
$_['title_1'] = 'Estrapola tutti i estensioni presenti in opencart';